package com.capgemini.asset.pi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.UserBean;
import com.capgemini.asset.service.AssetImpl;
import com.capgemini.asset.service.IAssetInterface;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	//private static final long serialVersionUID = 1L;
    //Connection con; 
	IAssetInterface ie=new AssetImpl();
      UserBean a=new UserBean();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/*public void init(ServletConfig config) throws ServletException {
		
	}*/

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().println("Login success....");
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		System.out.println(session.isNew()+" "+session.getId());
	
		a.setUserNameId(request.getParameter("UserName"));
		a.setPassword(request.getParameter("password"));
		//System.out.println(request.getParameter("role"));
		//a.setUserType(request.getParameter("role"));
		ServletContext context=getServletContext();
		context.setAttribute("username",request.getParameter("UserName"));
		/*Cookie c=new Cookie("UserName",request.getParameter("UserName"));
		response.addCookie(c);*/
		if(session!=null) {
		/*	response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Expires", 0);*/
		if(ie.dataAuthentication(a))
		{
			
			if(a.getUserType().equals("ADMIN")){
				request.getRequestDispatcher("/Admin.jsp").forward(request, response);
				
			}
			else
			{
				request.getRequestDispatcher("/Manager.jsp").forward(request, response);
			}
				
		
		}
		else
		{
			request.setAttribute("error", "invalid");
			request.getRequestDispatcher("/LoginPage.jsp").include(request, response);
			//response.sendRedirect("LoginPage.jsp");
		}
		
		}
		
		//doGet(request, response);
	
	
	}
	
	
}
