DROP TABLE subscriber_account_details cascade constraints;
DROP TABLE datasky_packages cascade constraints;

CREATE TABLE datasky_packages(package_id varchar2(6) primary   key,package_name varchar2(40) NOT NULL,package_amount NUMBER(8,2));

CREATE TABLE subscriber_account_details(subscriber_ID NUMBER(10) PRIMARY KEY,mobile_number NUMBER(10) UNIQUE NOT NULL ,package_id varchar2(6) references datasky_packages(package_ID),account_balance NUMBER(10,3),rechargedate DATE);

INSERT INTO datasky_packages VALUES('P001','DHAMMAL MIX',388);
INSERT INTO datasky_packages VALUES('P002','MEGA SOUTH SD',500);
INSERT INTO datasky_packages VALUES('P003','MEGA SOUTH HD',800);
INSERT INTO datasky_packages VALUES('P004','SUPREME SPORTS KIDS',650);

INSERT INTO subscriber_account_details VALUES(1016119800,9620466979,'P001',127.74,'25-SEP-2013');
INSERT INTO subscriber_account_details VALUES(1016119801,9920466998,'P002',227.74,'15-SEP-2013');
INSERT INTO subscriber_account_details VALUES(1016119802,9720478979,'P003',27.74,'29-SEP-2013'); 
COMMIT;

