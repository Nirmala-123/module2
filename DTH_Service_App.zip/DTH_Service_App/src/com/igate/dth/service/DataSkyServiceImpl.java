package com.igate.dth.service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.igate.dth.dao.DataSkyDaoImpl;
import com.igate.dth.dao.DataSkyDao;
import com.igate.dth.dto.Subscriber_Account_Details;
import com.igate.dth.exception.DataSkyException;
/*
 * Service layer - dispatching all calls to database layer
 */
public class DataSkyServiceImpl implements IDataSkyService {

	DataSkyDao skyDAO;

	public DataSkyServiceImpl() {
		skyDAO = new DataSkyDaoImpl();
	}

	@Override
	public ArrayList<Subscriber_Account_Details> showMobileNos(long operations) throws DataSkyException, SQLException, NamingException {
		return skyDAO.showMobileNos(operations);
	}

	@Override
	public int updateAmount(int opera2) throws DataSkyException, SQLException, NamingException {
		return skyDAO.updateAmount(opera2);
	}

}
