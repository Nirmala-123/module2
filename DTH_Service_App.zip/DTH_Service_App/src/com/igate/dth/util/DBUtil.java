package com.igate.dth.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.igate.dth.exception.DataSkyException;
/*
 * DBUtil class to access a connection pool 
 */
public class DBUtil {
	static Connection connection;

	public static Connection obtainConnection() throws DataSkyException, NamingException {
		try 
		{
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS");
			connection = source.getConnection();
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			//connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");
			// 10.219.34.3
		} 
		catch (SQLException e) 
		{
			throw new DataSkyException("Error while obtaining connection::"+ e.getMessage());
		}
		return connection;
	}
}