package com.igate.dth.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.dth.dto.Subscriber_Account_Details;
import com.igate.dth.exception.DataSkyException;
import com.igate.dth.service.DataSkyServiceImpl;
import com.igate.dth.service.IDataSkyService;


@WebServlet("/DTController")
public class DTController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	IDataSkyService service;
	RequestDispatcher view = null;
	ArrayList<Subscriber_Account_Details> sadList;
	Subscriber_Account_Details sade;
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();

		String reqAction = request.getParameter("action");	
		
		if (reqAction != null && "recharge".equals(reqAction)) 
		{
			view = request.getRequestDispatcher("MobileNumber.html");
			view.forward(request, response);
		}
		if (reqAction != null && "RechargeIt".equals(reqAction)) 
		{
		try {
			String operation = request.getParameter("mobileNo");
			long operations = Long.parseLong(operation);
			sade.setMobile_number(operations);
			service = new DataSkyServiceImpl();//
			sadList = new ArrayList<Subscriber_Account_Details>();
			sade = new Subscriber_Account_Details();
			sadList = service.showMobileNos(operations);
			
			if (sadList != null) {
				request.setAttribute("details", sadList);							
				view = request.getRequestDispatcher("ViewDetails.jsp");
				view.forward(request, response);
				pw.println("<a href='index.html'>Go Back to Home</a>");
				pw.println("</body>");
			} else {
				pw.println("Fetching dataSky details failed");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		} catch (DataSkyException e) {
			pw.println("Error while fetching Data Sky details");
			pw.print(e);
			pw.println(e.getMessage());
			view = request.getRequestDispatcher("error.html");
			view.include(request, response);
		} catch (SQLException e) {
			pw.println(e.getMessage());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}//END IF STATEMENT ...
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
		
		if (reqAction != null && "view".equals(reqAction)) 
		{
			view = request.getRequestDispatcher("Recharge.jsp");
			view.forward(request, response);
		}
		if (reqAction != null && "RCMobile".equals(reqAction)) 
		{

			String recharge = request.getParameter("recharge");
			int amt = Integer.parseInt(recharge);
			service = new DataSkyServiceImpl();		
			int result = 0;
			
			try 
			{
				if(amt>=100)
				{
				result = service.updateAmount(amt);
					if (result != 0) 
					{
						view = request.getRequestDispatcher("success.html");
						view.forward(request, response);
						pw.println("<a href='index.html'>Click to Home Page</a>");
						pw.println("</body>");
					} else 
					{
						view = request.getRequestDispatcher("error.html");
						view.forward(request, response);
						pw.println("<a href='index.html'>Click to Home Page</a>");
						pw.println("</body>");
					}
				}
				else
				{
					view = request.getRequestDispatcher("error.html");
					view.forward(request, response);
					pw.println("<a href='index.html'>Click to Home Page</a>");
					pw.println("</body>");
				}
			} catch (Exception e) {			
				System.err.println("EXCEPTION OCCURED "+e.getMessage());
			}
		}
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);

	}

}
