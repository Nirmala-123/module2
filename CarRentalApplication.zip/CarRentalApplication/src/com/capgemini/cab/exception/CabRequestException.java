package com.capgemini.cab.exception;

@SuppressWarnings("serial")
public class CabRequestException extends Exception {
public CabRequestException()
{
	
}
public CabRequestException(String msg)
{
	super(msg);
}
}
