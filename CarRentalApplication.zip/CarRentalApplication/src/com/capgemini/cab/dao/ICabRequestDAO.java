package com.capgemini.cab.dao;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabRequestDAO {
int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;
CabRequest getRequestDetails(int requestId) throws CabRequestException;
}
