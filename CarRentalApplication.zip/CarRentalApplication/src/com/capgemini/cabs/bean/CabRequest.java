package com.capgemini.cabs.bean;

public class CabRequest {
private String custName;
private String custPhoneNum;
private String custAddress;
private String custPinCode;
private String reqStatus;
private String cabNum;
public String getCustPhoneNum() {
	return custPhoneNum;
}
public void setCustPhoneNum(String custPhoneNum) {
	this.custPhoneNum = custPhoneNum;
}
public String getCabNum() {
	return cabNum;
}
public void setCabNum(String cabNum) {
	this.cabNum = cabNum;
}
public String getReqStatus() {
	return reqStatus;
}
public void setReqStatus(String reqStatus) {
	this.reqStatus = reqStatus;
}
public String getReqId() {
	return reqId;
}
public void setReqId(String reqId) {
	this.reqId = reqId;
}
private String reqId;
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getCustAddress() {
	return custAddress;
}
public void setCustAddress(String custAddress) {
	this.custAddress = custAddress;
}
public String getCustPinCode() {
	return custPinCode;
}
public void setCustPinCode(String custPinCode) {
	this.custPinCode = custPinCode;
}

}
