package com.capgemini.cabs.ui;

import java.util.Scanner;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;
import com.capgemini.cabs.bean.CabRequest;

public class Client {
	static ICabService cabServ=new CabService();
    static CabRequest cabRequest=new CabRequest();
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		String custName,phoneNum,address,pincode;
		while(true)
		{
		System.out.println("Select option from the given menu");
		System.out.println("1) Raise Cab Request\n2) View Cab Request Status\n3) Exit");
		int choice=scan.nextInt();
		
		switch(choice)
		{
		case 1:
			
			do{
				System.out.print("Enter the name of the customer:");
				custName=scan.next();
			}while(!cabServ.isValidName(custName));
			do{
				System.out.print("Enter customer phone number:");
				phoneNum=scan.next();
			}while(!cabServ.isValidNumber(phoneNum));
			do{
				System.out.print("Enter Pick up address:");
				address=scan.next();
			}while(!cabServ.isValidAddress(address));
			cabRequest.setCustName(custName);
			cabRequest.setCustPhoneNum(phoneNum);
			cabRequest.setCustAddress(address);
			System.out.print("Enter Pin Code:");
			pincode=scan.next();
			String carNum=cabServ.getCarNumber(pincode);
			if(carNum==null)
				cabRequest.setReqStatus("Not Accepted");
			else{
				cabRequest.setReqStatus("Accepted");
				cabRequest.setCabNum(carNum);
			}
			int reqId;
			try {
				reqId = cabServ.addCabRequestDetails(cabRequest);
				System.out.println("Your Cab Request has been successfully registered, your request ID is:<"+reqId+">");
			} catch (CabRequestException e) {
				System.err.println(e.getMessage());
			}
			break;
		case 2:
			cabServ=new CabService();
			System.out.print("Enter Request Id to check your details:");
			String requestId=scan.next();
			try{
				cabRequest=null;
				cabRequest=cabServ.getRequestDetails(Integer.parseInt(requestId));
			}catch (CabRequestException e) {
				System.err.println(e.getMessage());
			}
			if(cabRequest!=null)
			{
			System.out.println("Name of the Customer:"+cabRequest.getCustName());
			System.out.println("Request Status:"+cabRequest.getReqStatus());
			if(cabRequest.getReqStatus().equals("Accepted"))
			System.out.println("Cab number:"+cabRequest.getCabNum());
			}
			break;
		case 3:
		
			System.out.println("Thankyou");
			System.exit(0);
			break;
		}

	 }
   }	
}
