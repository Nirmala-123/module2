package com.capgemini.cab.test;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cabs.bean.CabRequest;

public class CabRequestDAOTest {

	static ICabRequestDAO cabRequestDao=new CabRequestDAO();
	static CabRequest cabRequest=new CabRequest();
	@BeforeClass
	public static void Initialize()
	{
		
	
	}
	@Test
	public void test() {
		
	}

}
